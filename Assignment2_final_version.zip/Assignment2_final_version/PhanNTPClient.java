import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.DecimalFormat;

public class PhanNTPClient {

	private static final String Default_Time_Server = "pool.ntp.org";
	private static final String Local_Time_Server = "localhost";
	private static final int Local_Server_port = 1000;

	public static void main(String[] args) throws IOException {

		// First NTP request to an Internet NTP server
		try {
			sendNTPRequest(Default_Time_Server, 123);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
		// Second NTP request to a local NTP server
		try {
			sendNTPRequest(Local_Time_Server, Local_Server_port);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}

	}

	private static void sendNTPRequest(String serverName, int port) throws Exception {
		try (DatagramSocket socket = new DatagramSocket()) {
			InetAddress serverAddr = InetAddress.getByName(serverName);
			byte[] buf = new NtpMessage().toByteArray();
			DatagramPacket packet = new DatagramPacket(buf, buf.length, serverAddr, port);
			NtpMessage.encodeTimestamp(packet.getData(), 40,
					(System.currentTimeMillis() / 1000.0) + 2208988800.0);
			socket.send(packet);
			// Receive response
			System.out.println("NTP request sent, waiting for response...\n");
			packet = new DatagramPacket(buf, buf.length);
			socket.receive(packet);
			// Immediately record the incoming timestamp
			double destinationTimestamp = (System.currentTimeMillis() / 1000.0) + 2208988800.0;
			// Process response
			NtpMessage msg = new NtpMessage(packet.getData());
			// Corrected, according to RFC2030 errata
			double roundTripDelay = (destinationTimestamp - msg.originateTimestamp) -
					(msg.transmitTimestamp - msg.receiveTimestamp);

			double localClockOffset = ((msg.receiveTimestamp - msg.originateTimestamp) +
					(msg.transmitTimestamp - destinationTimestamp)) / 2;

			// Display response
			System.out.println("NTP server: " + serverName);
			System.out.println(msg.toString());

			System.out.println("Dest. timestamp:     " +
					NtpMessage.timestampToString(destinationTimestamp));

			System.out.println("Round-trip delay: " +
					new DecimalFormat("0.00").format(roundTripDelay * 1000) + " ms");

			System.out.println("Local clock offset: " +
					new DecimalFormat("0.00").format(localClockOffset * 1000) + " ms");

			socket.close();
		}
	}

	/**
	 * Prints usage
	 */
	static void printUsage() {
		System.out.println(
				"NtpClient - an NTP client for Java.\n" +
						"\n" +
						"This program connects to an NTP server and prints the response to the console.\n" +
						"\n" +
						"\n" +
						"Usage: java NtpClient server\n" +
						"\n" +
						"\n" +
						"This program is copyright (c) Adam Buckley 2004 and distributed under the terms\n" +
						"of the GNU General Public License.  This program is distributed in the hope\n" +
						"that it will be useful, but WITHOUT ANY WARRANTY; without even the implied\n" +
						"warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU\n" +
						"General Public License available at http://www.gnu.org/licenses/gpl.html for\n" +
						"more details.");

	}
}